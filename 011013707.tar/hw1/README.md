# RandomAccessFilesystem

Project for Databases class

[requires g++ from command line, tested on MacOS]

run 'chmod u+x tests.sh'

create empty dirs /bin and /objs (if they dont exist)

run './tests.sh'